def addition(value1, value2):
    result = value1 + value2
    return result
def substract(value1, value2):
    result = value1 - value2
    return result

doAgain = True
print("Mein Rechner")
while(doAgain == True):
    val1 = input("geben sie die erste Zahl ein")
    val1 = float(val1)
    val2 = float(input("geben sie die zweite Zahl ein"))

    operator = input("geben sie die Rechenoperation eim (+,-,*,/)")
    if(operator=="+"):
        result=addition(val1, val2)
    elif(operator=="-"):
        result=substract(val1, val2)
    else:
        print("unbekannter Operator")

    print("Das Ergebnis lautet {0}".format(result))
    answer = input("möchten sie nochmal rechnen? (j/n)")
    if(answer.lower() == "j"):
        doAgain = True
    else:
        doAgain = False

        
