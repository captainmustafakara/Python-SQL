print("Hallo Welt")

MyName = "GERNOT"

print("Hallo " + MyName)

zahl1 = 13
zahl2 = 5
ergebnis = zahl1 % zahl2

print(ergebnis)
