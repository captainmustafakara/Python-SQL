import tkinter as tk

win = tk.Tk()

win.title("Testfenszer")
win.geometry("500x500")
win.resizable(False, False)




win.mainloop()
