#DDL und DML Statements
# Tabellen erstellen
CREATE TABLE Persons
(
	PersonID INT NOT NULL PRIMARY KEY,
	LastName VARCHAR(50) NOT NULL,
	FirstName VARCHAR(50) Null,
	height float NOT NULL,
	weight float NOT NULL
);
CREATE TABLE Hobbies
(
	HobbyID INT NOT NULL PRIMARY KEY,
	Name VARCHAR(50) NOT NULL
);
CREATE TABLE Person_Hobbies
(
	PersonID INT NOT NULL,
	HobbyID INT NOT NULL,
	FOREIGN KEY(PersonID) REFERENCES Persons(PersonID),
	FOREIGN KEY(HobbyID) REFERENCES Hobbies(HobbyID),
	PRIMARY KEY(PersonID, HobbyID)
);

#Daten einfügen
INSERT INTO Persons (PersonID, LastName, FirstName, height, weight)
			VALUES (1, 'Grünewald', 'Gernot', 1.85, 110);
INSERT INTO Persons VALUES (2, 'Tonne', 'Tina', 1.65, 70),
							(3, 'Mustermann', 'Manni', 1.70, 65);
INSERT INTO Hobbies VALUES (1, 'Programmieren'),
							(2, 'Kochen'),
							(3, 'Sport'),
							(4, 'Essen');	
insert into Person_Hobbies VALUES (1, 2),
									(2, 3),
									(2, 4),
									(3, 3);	

# Abfrage der Eingegebenen Daten
SELECT LastName, Name
	FROM Persons, Hobbies, Person_Hobbies
	WHERE Persons.PersonID = Person_Hobbies.PersonID
		and Person_Hobbies.HobbyID = Hobbies.HobbyID									