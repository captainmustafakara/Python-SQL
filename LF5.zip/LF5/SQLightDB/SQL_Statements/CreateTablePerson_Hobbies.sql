CREATE TABLE Person_Hobbies
(
	PersonID INT NOT NULL,
	HobbyID INT NOT NULL,
	FOREIGN KEY(PersonID) REFERENCES Persons(PersonID),
	FOREIGN KEY(HobbyID) REFERENCES Hobbies(HobbyID),
	PRIMARY KEY(PersonID, HobbyID)
);