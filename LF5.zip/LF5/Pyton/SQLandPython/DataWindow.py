import tkinter
import sqlite3

def getAndFillData(id):
    con = sqlite3.connect("C:\\Users\\Student\\Desktop\\Pyton\\SQLandPython\\Person.db")
    cursor = con.cursor()
    sql = "Select PersonID, LastName, FirstName from Persons where PersonID="+str(id)
    cursor.execute(sql)
    datalist = cursor.fetchall()
    con.close()
    
    txtPersonID.insert(0, datalist[0][0])
    txtLastName.insert(0, datalist[0][1])
    txtFirstName.insert(0, datalist[0][2])
    

win = tkinter.Tk()

win.title("DataWindow")
win.geometry("240x150")
win.resizable(False, False)

lblPersonID = tkinter.Label(text = "PersonenID")
lblPersonID.place(x=10, y=30)

txtPersonID = tkinter.Entry()
txtPersonID.place(x=90, y=30)

lblLastName = tkinter.Label(text = "Nachname")
lblLastName.place(x=10, y=50)

txtLastName = tkinter.Entry()
txtLastName.place(x=90, y=50)

lblFirstName = tkinter.Label(text = "Vorname")
lblFirstName.place(x=10, y=70)

txtFirstName = tkinter.Entry()
txtFirstName.place(x=90, y=70)

getAndFillData(1)


win.mainloop()
