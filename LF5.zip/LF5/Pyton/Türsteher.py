#Türsteher
alter = int(input("hallo, wie alt bist du"))
if alter < 18:
    print("du bist zu jung, tschüß")
    print("geh nach hause zu Mama")
else:
    if alter == 18:
        print("glückwunsch, di darfst jetzt auch mitmachen")
    else:
        print("komm rein, hab spaß")
print("der nächste bitte")
