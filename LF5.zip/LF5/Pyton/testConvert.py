
try:
    wert = "12s4"

    zahl = int(wert)
except Exception as e:
    print("Es ist ein Fehler aufgetreten:\n" + e.args[0])
else:
    print(zahl * 2)
print("Es geht weiter")
