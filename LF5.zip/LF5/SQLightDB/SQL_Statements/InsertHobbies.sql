INSERT INTO Hobbies VALUES (1, 'Programmieren'),
							(2, 'Kochen'),
							(3, 'Sport'),
							(4, 'Essen');