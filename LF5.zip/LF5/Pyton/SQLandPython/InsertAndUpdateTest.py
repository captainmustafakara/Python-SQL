import sqlite3  as s3

con = s3.connect("person.db")

cur = con.cursor()

sqlinsert = "insert into Persons values (4, 'Ratlos', 'Reiner', 1.70, 90)"
cur.execute(sqlinsert)

sqlupdate = "update Persons set FirstName = 'Gernot Franz' where PersonID = 1"
cur.execute(sqlupdate)

con.commit()

con.close()

