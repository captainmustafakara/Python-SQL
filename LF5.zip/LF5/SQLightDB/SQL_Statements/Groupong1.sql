SELECT CustomerID as KundenNR, 
		count(OrderID) as 'Ant. Bestellungen'
		FROM Orders
	GROUP BY CustomerID