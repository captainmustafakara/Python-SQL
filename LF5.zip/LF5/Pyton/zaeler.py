#Zählen
zaehler = 1
while zaehler <= 10:
    print ("Duechgang " + str(zaehler))
    zaehler = zaehler + 1
print ("fertig")
