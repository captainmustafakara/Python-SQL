SELECT LastName, Name
	FROM Persons, Hobbies, Person_Hobbies
	WHERE Persons.PersonID = Person_Hobbies.PersonID
		and Person_Hobbies.HobbyID = Hobbies.HobbyID