select sum(Quantity * UnitPrice)
	from 'Order Details' as od 
		join Orders as o on o.OrderID = od.OrderID
	where CustomerID = 'ALFKI'

