wert1 = 2345
wert2 = 1234
text = "Die Summe von {0} und {1} ist {2}"
print(text.format(wert1, wert2, wert1+wert2))
