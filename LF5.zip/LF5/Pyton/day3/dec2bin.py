#dec2bin

#Eingabe
decval = int(input("Gebe eine Dezimalzahl ein"))
binval = "" #binval als String

#verarbeiten
while decval > 0:
    if decval % 2 == 0:
        binval = "0" + binval
    else:
        binval = "1" + binval
    decval = decval // 2

#ausgabe
print(binval)
