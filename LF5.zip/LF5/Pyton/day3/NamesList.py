names = []
def inputNames():
    while(True):
        name = input("Geben sie einen Namen ein ")
        if(name ==  " " or name == "" or name == "exit"):
            break
        names.append(name)
        print("{} wurde der Liste hinzugefügt".format(name))
def printNames():
    i = 0
    for name in names:
        print("Index: {0}; Name: {1}".format(i, name))
        i+=1
def loadNames():
    names.clear()
    datastream = open("NameList.txt", "r")
    for line in datastream:
        #neu
        line = line.replace("\n","")
        names.append(line)
    datastream.close()
    print("Liste geladen")

def saveNames():
    datastream = open("NameList.txt", "w")
    for name in names:
        if(name.endswith("\n")):
            datastream.write(name)
        else:
            datastream.write(name + "\n")
    datastream.close()
    print("Liste gespeichert")

def deleteNameAtIndex():
    printNames()
    index = int(input("geben sie den index der Person ein"))
    #Überprüfen ob index im Bereich
    name = names.pop(index)
    print ("Der Name {0} wurde gelöscht".format(name))

loadNames()
while (True):
    print("1 Namen anzeigen")
    print("2 liste laden")
    print("3 Namen anfügen")
    print("4 Name löschen")
    print("5 liste speichern")
    print("9 Verlasse Programm")
    choose = input("Bitte wählen")
    if choose == "1":
        printNames()
    elif choose == "2":
        loadNames()
    elif choose == "3":
        inputNames()
    elif choose == "4":
        deleteNameAtIndex()
    elif choose == "5":
        saveNames()
    elif choose == "9":
        break

saveNames()
print ("Programm ENDE")
    
    


