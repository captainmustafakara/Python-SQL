#Zufallszahlen
import random

#print(random.random())

#print(random.randint(1, 49))

#Lotto

numberlist = range(1, 50)
lottolist =random.sample(numberlist, 6)
lottolist.sort()
#for num in lottolist:
print(', '.join(str(val) for val in lottolist))
