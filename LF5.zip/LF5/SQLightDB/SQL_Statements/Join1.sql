SELECT DISTINCT CompanyName as Kinde, ProductName as Product
		from Customers as c
			join Orders as o on c.CustomerID = o.CustomerID
			join 'Order Details' as od on o.OrderID = od.OrderID
			join Products as p on od.ProductID = p.ProductID
	where c.CustomerID = 'ALFKI'