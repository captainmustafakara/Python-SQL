INSERT INTO Persons (PersonID, LastName, FirstName, height, weight)
			VALUES (1, 'Grünewald', 'Gernot', 1.85, 110);
			
INSERT INTO Persons VALUES (2, 'Tonne', 'Tina', 1.65, 70),
							(3, 'Mustermann', 'Manni', 1.70, 65);