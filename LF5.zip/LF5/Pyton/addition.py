#geginn
zahl1 = 0
zahl2 = 0
print("geben siedie erste Zahl ein")
zahl1 = input()
zahl1 = int(zahl1)
print("geben siedie zweite Zahl ein")
zahl2 = input()
zahl2 = int(zahl2)
ergebnis = zahl1 + zahl2
print(ergebnis)
#ende
