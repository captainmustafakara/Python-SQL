CREATE TABLE Persons
(
	PersonID INT NOT NULL PRIMARY KEY,
	LastName VARCHAR(50) NOT NULL,
	FirstName VARCHAR(50) Null,
	height float NOT NULL,
	weight float NOT NULL
);