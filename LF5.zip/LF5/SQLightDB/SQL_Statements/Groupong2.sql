select FirstName, LastName, 
		count(DISTINCT CustomerID)
		from Employees as e
			join Orders as o
				on e.EmployeeID = o.EmployeeID
	GROUP BY FirstName, LastName
		HAVING count(DISTINCT CustomerID) >= 50