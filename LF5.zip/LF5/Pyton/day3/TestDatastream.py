#datei auslesen
datastream = open("Example.txt", "r")
text = datastream.read()
datastream.close
print(text)

#datei schreiben
datastream = open("Example.txt", "a")
datastream.write("Dieser Text wurde angehängt\n")
datastream.close()
