import sqlite3 

con = sqlite3.connect("C:\\Users\\Student\\Desktop\\Pyton\\SQLandPython\\Person.db")

cursor = con.cursor()
sql = "Select PersonID, LastName, FirstName from Persons"

cursor.execute(sql)

datalist = cursor.fetchall()

con.close()

print("Anzahl Datenzeilen: {}".format(len(datalist)))

for row in datalist:
    print(row[0],row[1],row[2],sep="\t|\t")

