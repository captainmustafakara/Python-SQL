insert into Person_Hobbies VALUES (1, 2),
									(2, 3),
									(2, 4),
									(3, 3)