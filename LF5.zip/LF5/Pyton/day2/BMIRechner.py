#BMI Rechner

def calkBMIIndex(weight, height):
    height = height / 100
    bmi = weight / (height**2)
    return bmi

def getBMIZext(bmi):
    text = ""
    if bmi < 18.9:
        text = "Untergwicht"
    elif bmi < 24.9:
        text = "Normalgewicht"
    elif bmi < 29.9:
        text = "Übergewicht"
    elif bmi < 34.9:
        text = "Adipositas 1"
    elif bmi < 39.9:
        text = "Adipositas 2"
    else:
        text = "Adipositas 3"
    return text

def getNumValue(value):
    val = 0
    if value.isnumeric():
        val = float(value)
    else:
        print("Keine Zahl!")
    return val


print("BMI-Rechner")
height = 0
weight = 0
while(height < 50 or height > 250):
    height = input("Bitte geben sie ihre Kürpergöße in cm an (Ganzzahl): ")
    height = getNumValue(height)
while(weight < 25 or weight > 300):
    weight = input("Bitte geben sie ihr Gewicht in kg an (Ganzzahl): ")
    weight = getNumValue(weight)
bmiIndex = calkBMIIndex(weight, height)
bmiText = getBMIZext(bmiIndex)

print("Sie haben einen BMI von {0:0.2f}".format(bmiIndex))
print("Sie haben " + bmiText)

    
